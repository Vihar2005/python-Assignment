for i in range(10):
    print(i)
print("*"*10)

for i in range(3,10):
    print(i)
print("*"*10)

for i in range(1,10,3):
    print(i)
print("*"*10)

for i in range(10,0,-1):
    print(i)
print("*"*10)
