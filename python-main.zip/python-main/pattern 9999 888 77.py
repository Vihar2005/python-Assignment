for i in range(9,0,-1):
    print(" "*(9-i),(" "+str(i))*i)
