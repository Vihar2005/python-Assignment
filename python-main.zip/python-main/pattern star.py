'''
  *
 * *
* * *
'''

for i in range(1,10):
    print(" "*(9-i)," *"*i)
