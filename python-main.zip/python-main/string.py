#  01234567890123456    +
s="Tops technologies"
#  76543210987654321    -

print(s[3:13])
print(s[:12])
print(s[7:])
print(s[1:15:3])
print(s[::5])

print(s[-14:-3])
print(s[:-5])
print(s[-12:])
print(s[-15:-5:5])
print(s[::-1])
