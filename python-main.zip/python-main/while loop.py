n=int(input("enter n : "))
sum=1
while n>0:
    sum=sum-n
    n=n-1
    print("sum : ",sum)
